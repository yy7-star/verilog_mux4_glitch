
# verilog_mux4_glitch

## 项目概述
4选1无毛刺时钟切换电路，通过3个 mux2 模块拼接实现，确保时钟切换过程中输出无毛刺。

## 目录结构
verilog_mux4_glitch/
├── rtl/
│ └── mux4_glitch.v
├── tb/
│ └── tb_mux4_glitch.v
└── sim/
├── Makefile
└── run_sim.sh

## 模块端口
| 端口名 | 方向 | 说明 |
|--------|------|------|
| clk_A  | input | 时钟通道A输入 |
| clk_B  | input | 时钟通道B输入 |
| clk_C  | input | 时钟通道C输入 |
| clk_D  | input | 时钟通道D输入 |
| sel0   | input | 选择信号bit0 |
| sel1   | input | 选择信号bit1 |
| rst_nA | input | 通道A异步复位 |
| rst_nB | input | 通道B异步复位 |
| rst_nC | input | 通道C异步复位 |
| rst_nD | input | 通道D异步复位 |
| clk_out| output | 输出时钟 |

## 选择逻辑
| sel1 | sel0 | 输出 |
|------|------|------|
| 0    | 0    | clk_A |
| 0    | 1    | clk_B |
| 1    | 0    | clk_C |
| 1    | 1    | clk_D |



##注意
所有复位信号异步有效，需在仿真开始时正确释放
选择信号变化时，输出会在几个时钟周期后完成切换
切换过程中输出会短暂保持原时钟状态，不会出现毛刺
