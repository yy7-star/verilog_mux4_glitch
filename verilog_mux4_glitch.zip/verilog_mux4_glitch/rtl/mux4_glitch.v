
`timescale 1ns/1ps

module mux4_glitch (
    input  wire  clk_A,
    input  wire  clk_B,
    input  wire  clk_C,
    input  wire  clk_D,
    input  wire  sel0,
    input  wire  sel1,
    input  wire  rst_nA,
    input  wire  rst_nB,
    input  wire  rst_nC,
    input  wire  rst_nD,
    output wire  clk_out
);

wire clk_ab;
wire clk_cd;

mux2_glitch mux_ab (
    .clk_A(clk_A),
    .clk_B(clk_B),
    .sel(sel0),
    .rst_nA(rst_nA),
    .rst_nB(rst_nB),
    .clk_out(clk_ab)
);

mux2_glitch mux_cd (
    .clk_A(clk_C),
    .clk_B(clk_D),
    .sel(sel0),
    .rst_nA(rst_nC),
    .rst_nB(rst_nD),
    .clk_out(clk_cd)
);

mux2_glitch mux_out (
    .clk_A(clk_ab),
    .clk_B(clk_cd),
    .sel(sel1),
    .rst_nA(rst_nA),
    .rst_nB(rst_nC),
    .clk_out(clk_out)
);

endmodule
