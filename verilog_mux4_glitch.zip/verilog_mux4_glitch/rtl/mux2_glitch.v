
`timescale 1ns / 1ps
module mux2_glitch (
    input  wire  clk_A,
    input  wire  clk_B,
    input  wire  sel,
    input  wire  rst_nA,
    input  wire  rst_nB,
    output wire  clk_out
);

wire a1o;
reg a1o_r;
reg a1o_sync;
reg a2i_2;
wire a2o;
wire a3o;
reg a3o_r;
reg a3o_sync;
reg a4i_2;
wire a4o;
wire a1i_2;
wire a3i_2;


assign a1o=(~sel)&a1i_2;

always @(posedge clk_A or negedge rst_nA)
begin
    if(!rst_nA)
    begin
        a1o_r<=1'b1;
        a1o_sync<=1'b1;
    end
    else
    begin
        a1o_r<=a1o;
        a1o_sync<=a1o_r;
    end
end

always @(negedge clk_A or negedge rst_nA)
begin
    if(!rst_nA)
        a2i_2<=1'b1;
    else
        a2i_2<=a1o_sync;
end

assign a2o=clk_A & a2i_2;


assign a3o=sel & a3i_2; 

always @(posedge clk_B or negedge rst_nB)
begin
    if(!rst_nB)
    begin
        a3o_r<=1'b0;
        a3o_sync<=1'b0;
    end
    else
    begin
        a3o_r<=a3o;
        a3o_sync<=a3o_r;
    end
end

always @(negedge clk_B or negedge rst_nB)
begin
    if(!rst_nB)
        a4i_2<=1'b0;
    else
        a4i_2<=a3o_sync;
end

assign a4o=clk_B & a4i_2;

assign a1i_2 =~(a4i_2);
assign a3i_2 =~(a2i_2);

assign clk_out = a2o|a4o;

endmodule
