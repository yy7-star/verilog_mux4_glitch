

 run_sim.sh
 vcs -sverilog \
 ../rtl/mux2_glitch.v \
 ../rtl/mux4_glitch.v\
 ../tb/tb_mux4_glitch.v \
     -full64\
     -debug_access+all\
     -kdb\
     -R\
     -gui\

