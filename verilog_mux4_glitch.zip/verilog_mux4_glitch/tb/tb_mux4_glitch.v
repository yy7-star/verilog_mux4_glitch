
`timescale 1ns/1ps

module tb_mux4_glitch;

reg         clk_A;
reg         clk_B;
reg         clk_C;
reg         clk_D;
reg         sel0;
reg         sel1;
reg         rst_nA;
reg         rst_nB;
reg         rst_nC;
reg         rst_nD;
wire        clk_out;

mux4_glitch u_mux(
    .clk_A(clk_A),
    .clk_B(clk_B),
    .clk_C(clk_C),
    .clk_D(clk_D),
    .sel0(sel0),
    .sel1(sel1),
    .rst_nA(rst_nA),
    .rst_nB(rst_nB),
    .rst_nC(rst_nC),
    .rst_nD(rst_nD),
    .clk_out(clk_out)
);

initial begin
    clk_A = 1'b0;
    #100;
    forever #5 clk_A = ~clk_A;
end

initial begin
    clk_B = 1'b0;
    #77;
    forever #10 clk_B = ~clk_B;
end

initial begin
    clk_C = 1'b0;
    #120;
    forever #7 clk_C = ~clk_C;
end

initial begin
    clk_D = 1'b0;
    #50;
    forever #15 clk_D = ~clk_D;
end

initial begin
    rst_nA = 1'b0;
    #1000;
    @(posedge clk_A);
    rst_nA = 1'b1;
end

initial begin
    rst_nB = 1'b0;
    #1000;
    @(posedge clk_B);
    rst_nB = 1'b1;
end

initial begin
    rst_nC = 1'b0;
    #1000;
    @(posedge clk_C);
    rst_nC = 1'b1;
end

initial begin
    rst_nD = 1'b0;
    #1000;
    @(posedge clk_D);
    rst_nD = 1'b1;
end

initial begin
    sel0 = 1'b0;
    sel1 = 1'b0;
    #5000;
    sel0 = 1'b1;
    sel1 = 1'b0;
    #5000;
    sel0 = 1'b0;
    sel1 = 1'b1;
    #5000;
    sel0 = 1'b1;
    sel1 = 1'b1;
    #5000;
    sel0 = 1'b0;
    sel1 = 1'b0;
    #5000;
    $finish;
end

initial begin
    $dumpfile("mux4_glitch_free.vcd");
    $dumpvars(0, tb_mux4_glitch);
end

endmodule
